export const environment = {
    
    // baseUrl:  "https://api-clinicmanagement.rsdemoprojects.in/api",
    // baseUrlLocal : "https://api-clinicmanagement.rsdemoprojects.in/api",
    baseUrl:'https://www.api.medipilot360.com/api'
 
};