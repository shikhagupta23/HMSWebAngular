import { Component } from '@angular/core';

@Component({
  selector: 'app-addappointment',
  standalone: false,
  templateUrl: './addappointment.html',
  styleUrl: './addappointment.scss',
})
export class Addappointment {

}
