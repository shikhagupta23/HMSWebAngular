import { Component } from '@angular/core';

@Component({
  selector: 'app-view-todays-patients',
  standalone: false,
  templateUrl: './view-todays-patients.html',
  styleUrl: './view-todays-patients.scss',
})
export class ViewTodaysPatients {

}
