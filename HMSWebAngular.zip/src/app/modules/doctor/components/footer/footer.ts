import { Component } from '@angular/core';

@Component({
  selector: 'apppp-footer',
  standalone: false,
  templateUrl: './footer.html',
  styleUrl: './footer.scss',
})
export class Footer {

}
