import { Component } from '@angular/core';

@Component({
  selector: 'app-labtest',
  standalone: false,
  templateUrl: './labtest.html',
  styleUrl: './labtest.scss',
})
export class Labtest {

}
