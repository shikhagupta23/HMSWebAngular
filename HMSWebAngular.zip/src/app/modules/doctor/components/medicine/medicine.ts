import { Component } from '@angular/core';

@Component({
  selector: 'app-medicine',
  standalone: false,
  templateUrl: './medicine.html',
  styleUrl: './medicine.scss',
})
export class Medicine {

}
