import { Component } from '@angular/core';

@Component({
  selector: 'app-appointments',
  standalone: false,
  templateUrl: './appointments.html',
  styleUrl: './appointments.scss',
})
export class Appointments {

}
